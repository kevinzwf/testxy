<?php

/**
 * 后台入口文件
 */

header("location: ../index.php?s=".basename(dirname(__FILE__)));