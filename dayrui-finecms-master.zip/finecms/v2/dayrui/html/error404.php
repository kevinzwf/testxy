<html><head>
<meta http-equiv="content-type" content="text/html;charset=utf-8">
<title>404 Not Found</title>
<style>
body {font-family:"微软雅黑",arial,sans-serif}
a{font-size:12px;}
</style>
</head>
<body text=#000000 bgcolor=#ffffff>
<table border=0 cellpadding=2 cellspacing=0 width=100%><tr><td rowspan=3 width=1% nowrap>
<b><font face=times color=#0039b6 size=10>M</font><font face=times color=#c41200 size=10>e</font><font face=times color=#f3c518 size=10>s</font><font face=times color=#0039b6 size=10>s</font><font face=times color=#30a72f size=10>a</font><font face=times color=#c41200 size=10>g</font><font face=times color=#0039b6 size=10>e</font>&nbsp;&nbsp;</b></td>
<td>&nbsp;</td></tr>
<tr><td bgcolor="#3366cc"><font face=arial,sans-serif style="color:#FFF;"><b>404Error</b></font></td></tr>
<tr><td>&nbsp;</td></tr></table>
<blockquote>
<H1><?php echo lang('app-7')?></H1>
The requested URL was not found on this server.   
<div style="padding-top:10px;">
<?php echo lang('app-6');?>(#<?php echo $id;?>)
<?php echo lang('app-' . $id);?>
</div>
</blockquote>
<table width=100% cellpadding=0 cellspacing=0><tr><td height="3" bgcolor="#3366cc"></td></tr></table>
</body></html>