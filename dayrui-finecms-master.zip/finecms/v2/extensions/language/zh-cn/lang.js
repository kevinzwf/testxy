/*
 * FineCMS语言文件 for js
 */

var fc_lang = new Array();
fc_lang[0]  = '没有图片';
fc_lang[1]  = '预览';
fc_lang[2]  = '移除';
fc_lang[3]  = '上传';
fc_lang[4]  = '排序';
fc_lang[5]  = '鼠标拖动即可';
fc_lang[6]  = '确定';
fc_lang[7]  = '取消';
fc_lang[8]  = '正在上传请稍后...';
fc_lang[9]  = '正在上传';
fc_lang[10] = '请稍后...';
fc_lang[11] = '文件上传成功';
fc_lang[12] = '上传错误';
fc_lang[13] = '服务器 I/O 错误';
fc_lang[14] = '服务器安全认证错误';
fc_lang[15] = '附件安全检测失败，上传终止';
fc_lang[16] = '上传取消';
fc_lang[17] = '上传终止';
fc_lang[18] = '单次上传文件数限制为 ';
fc_lang[19] = '请不要上传空文件';
fc_lang[20] = '队列文件数量超过设定值';
fc_lang[21] = '文件尺寸超过设定值';
fc_lang[22] = '文件类型不合法';
fc_lang[23] = '上传错误，请与管理员联系！';
fc_lang[24] = '您还没有上传';
fc_lang[25] = '文件信息';
fc_lang[26]  = '没有文件';