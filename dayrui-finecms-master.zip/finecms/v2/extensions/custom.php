<?php

if (!defined('IN_FINECMS')) exit();

/**
 *  custom.php 用户自定义函数/类库
 */
