<?php 
/* UCenter配置 */
/* UCenter配置 */
define('UC_CONNECT', 'mysql');
define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'root');
define('UC_DBNAME', 'cms');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`cms`.pre_ucenter_');
define('UC_DBCONNECT', '0');
define('UC_KEY', 'af88YZutcGsWxjWd4X1bzYr2YU+R/pj/b8mIVSo');
define('UC_API', 'http://localhost/discuz_x2.5/uc_server');
define('UC_CHARSET', 'utf-8');
define('UC_IP', '');
define('UC_APPID', '2');
define('UC_PPP', '20');
/* FineCMS配置 */
$dbhost    = 'localhost:3306';
$dbuser    = 'root';
$dbpw      = '';
$dbname    = 'finecms';
$pconnect  = 0;
$tablepre  = 'fn_';
$dbcharset = 'utf8';
/* 同步登录Cookie */
$cookiedomain = '';
$cookiepath   = '/';
$cookiepre    = 'finecms_';
/* FineCMS配置 */
$dbhost    = 'localhost:3306';
$dbuser    = 'root';
$dbpw      = 'root';
$dbname    = 'cms';
$pconnect  = 0;
$tablepre  = 'fn_';
$dbcharset = 'utf8';
/* 同步登录Cookie */
$cookiedomain = '';
$cookiepath   = '/';
$cookiepre    = 'finecms_b1bf4_';
$cookiecode   = '2967e68d382902a';
?>