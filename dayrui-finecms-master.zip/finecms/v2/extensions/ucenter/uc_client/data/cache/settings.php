<?php
$_CACHE['settings'] = array (
);

?>