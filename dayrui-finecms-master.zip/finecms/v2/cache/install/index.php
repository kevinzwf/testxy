<?php

define('SITE_DIR', basename(__FILE__)); // 目录名称

require '../index.php'; // 引入主文件