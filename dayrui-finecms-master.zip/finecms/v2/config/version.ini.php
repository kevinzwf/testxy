<?php
return array(

	'cms' => 'FineCMS',
	'name' => 'FineCMS公益版',
    'company' => '罗氏工作室',
	'version' => '2.2.0',
	'update' => '2017-3-23',

);