<?php
if (!defined('IN_FINECMS')) exit();

/**
 * 多站点域名配置文件
 */
return array(

	'1'  => 'www.v1.com', 
	'2'  => 'atest.finecms.net', 

);